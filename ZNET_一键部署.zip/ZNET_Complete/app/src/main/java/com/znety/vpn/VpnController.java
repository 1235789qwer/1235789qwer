package com.znety.vpn;

import org.json.JSONObject;

import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

/**
 * VPN 弱网控制器：以原子变量保存全部整形参数，隧道线程每次发包读取最新值，
 * 因此「运行中改参数」即时生效，无需断流重连。
 *
 * 参数约定：-1 表示「默认/不限制」，>=0 表示启用该限制。
 */
public class VpnController {

    private static final VpnController INSTANCE = new VpnController();

    // 下行（入站）：应用接收方向
    public final AtomicInteger downBw      = new AtomicInteger(-1); // kb/s
    public final AtomicInteger downDelay   = new AtomicInteger(-1); // ms
    public final AtomicInteger downJitter  = new AtomicInteger(-1); // ms
    public final AtomicInteger downBurst   = new AtomicInteger(-1); // ms 通包时长
    public final AtomicInteger downLoss    = new AtomicInteger(-1); // %
    public final AtomicInteger downBurstLoss = new AtomicInteger(-1); // % 突发丢包
    // 上行（出站）
    public final AtomicInteger upBw        = new AtomicInteger(-1);
    public final AtomicInteger upDelay     = new AtomicInteger(-1);
    public final AtomicInteger upLoss      = new AtomicInteger(-1);

    private volatile String targetPackage = ""; // 只对指定应用生效，空=全局

    // 令牌桶（带宽限制）
    private final AtomicLong lastRefill = new AtomicLong(System.currentTimeMillis());
    private final AtomicLong tokens     = new AtomicLong(0);

    public static VpnController getInstance() { return INSTANCE; }

    /** 前端实时更新参数 */
    public void updateConfig(JSONObject d) {
        if (d == null) return;
        downBw.set(d.optInt("downBw", -1));
        downDelay.set(d.optInt("downDelay", -1));
        downJitter.set(d.optInt("downJitter", -1));
        downBurst.set(d.optInt("downBurst", -1));
        downLoss.set(d.optInt("downLoss", -1));
        downBurstLoss.set(d.optInt("downBurstLoss", -1));
        upBw.set(d.optInt("upBw", -1));
        upDelay.set(d.optInt("upDelay", -1));
        upLoss.set(d.optInt("upLoss", -1));
        if (d.has("package")) targetPackage = d.optString("package", "");
    }

    public String getTargetPackage() { return targetPackage; }
    public void setTargetPackage(String pkg) { this.targetPackage = pkg == null ? "" : pkg; }

    public int getDownBwKbps() { return downBw.get(); }
    public int getDownDelay() { return downDelay.get(); }

    /** 令牌桶：每秒补充 bwKbps*1000/8 字节；返回是否放行本次 packetLen 字节 */
    public boolean acquireBandwidth(int bwKbps, int packetLen) {
        if (bwKbps <= 0) return true; // -1 或 0 = 不限速
        long now = System.currentTimeMillis();
        long elapsed = now - lastRefill.getAndSet(now);
        long cap = (long) bwKbps * 1000 / 8; // 每秒字节容量
        long add = cap * elapsed / 1000;
        long t = Math.min(cap, tokens.addAndGet(add));
        if (t >= packetLen) { tokens.addAndGet(-packetLen); return true; }
        return false; // 超出带宽，丢弃
    }

    /** 是否丢包：综合丢包率 + 突发丢包（简化：以较大者概率判定） */
    public boolean shouldDrop() {
        int loss = Math.max(downLoss.get(), downBurstLoss.get());
        if (loss <= 0) return false;
        return Math.random() * 100 < loss;
    }
}
