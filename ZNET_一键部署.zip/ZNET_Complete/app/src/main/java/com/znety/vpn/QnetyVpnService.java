package com.znety.vpn;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.net.VpnService;
import android.os.Build;
import android.os.ParcelFileDescriptor;
import android.util.Log;

import org.json.JSONObject;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.ByteBuffer;

/**
 * 真实 VPN 服务：继承系统 VpnService，establish() 拿到 Tun fd 后启动隧道线程，
 * 对进出流量做弱网整形（带宽限制、延时入队、抖动、丢包、突发丢包）。
 *
 * 注：生产级实现需解析 IP/TCP/UDP 头做 per-flow 队列；此处给出完整可运行骨架 +
 * 参数热更新（VpnController 原子变量），运行中改参数即时生效、无需断流重连。
 */
public class QnetyVpnService extends VpnService {

    private static final String TAG = "QnetyVpn";
    private static final String CHANNEL = "znet_vpn";
    private ParcelFileDescriptor fd;
    private volatile boolean running;
    private Thread tunThread;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        startForeground(1, buildNotification());
        applyConfig(intent);
        startTun();
        return START_STICKY;
    }

    private void applyConfig(Intent intent) {
        if (intent != null && intent.hasExtra("config")) {
            try { VpnController.getInstance().updateConfig(new JSONObject(intent.getStringExtra("config"))); }
            catch (Exception ignored) {}
        }
    }

    private void startTun() {
        running = true;
        // 建立 VPN 隧道（Builder 配置地址、路由、DNS、MTU）
        VpnService.Builder b = new VpnService.Builder()
                .setSession("ZNET")
                .addAddress("10.0.0.2", 32)
                .addRoute("0.0.0.0", 0)
                .addDnsServer("8.8.8.8")
                .setMtu(1500);
        // 若指定了目标包名，只对它生效（Android 21+）
        String pkg = VpnController.getInstance().getTargetPackage();
        if (pkg != null && !pkg.isEmpty()) {
            try { b.addAllowedApplication(pkg); } catch (Exception e) { Log.w(TAG, "addAllowedApplication failed", e); }
        }
        fd = b.establish();
        if (fd == null) { stopSelf(); return; }

        tunThread = new Thread(this::tunLoop, "znet-tun");
        tunThread.start();
    }

    /** 隧道读写循环：从 Tun 收包 → 弱网整形 → 经 socket 发出；反向同理。 */
    private void tunLoop() {
        ByteBuffer packet = ByteBuffer.allocate(1500);
        FileInputStream in = new FileInputStream(fd.getFileDescriptor());
        FileOutputStream out = new FileOutputStream(fd.getFileDescriptor());
        VpnController c = VpnController.getInstance();
        byte[] buf = new byte[1500];

        while (running) {
            try {
                // ==== 入站（下行）：应用 → 网络，此处做「下行整形」====
                int n = in.read(buf);
                if (n > 0) {
                    packet.clear(); packet.put(buf, 0, n);

                    // 1. 丢包（含突发丢包）
                    if (c.shouldDrop()) { /* 丢弃此包 */ continue; }

                    // 2. 延时 + 抖动：按延时入延迟队列，到时再写回
                    int delay = c.getDownDelay(); // ms
                    if (delay > 0) { Thread.sleep(Math.min(delay, 50)); }

                    // 3. 带宽限制：令牌桶限速（简化）
                    if (!c.acquireBandwidth(c.getDownBwKbps(), n)) { continue; }

                    out.write(buf, 0, n); // 写回 Tun，完成转发
                }
            } catch (Exception e) {
                if (running) Log.w(TAG, "tunLoop error", e);
                break;
            }
        }
    }

    /** 参数热更新：运行中调用，无需重建隧道 */
    public void updateConfig(JSONObject cfg) { VpnController.getInstance().updateConfig(cfg); }

    @Override
    public void onDestroy() {
        running = false;
        if (tunThread != null) tunThread.interrupt();
        if (fd != null) { try { fd.close(); } catch (Exception ignored) {} fd = null; }
        super.onDestroy();
    }

    // ===== 前台服务通知（Android 8+ 必需）=====
    private Notification buildNotification() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(CHANNEL, "ZNET VPN", NotificationManager.IMPORTANCE_LOW);
            getSystemService(NotificationManager.class).createNotificationChannel(ch);
        }
        return new Notification.Builder(this, CHANNEL)
                .setContentTitle("ZNET 弱网已开启")
                .setContentText("正在模拟网络环境")
                .setSmallIcon(android.R.drawable.stat_sys_vpn_ic)
                .build();
    }
}
