package com.znety.vpn;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;

import java.io.File;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/**
 * APK 解析工具：读取包名、版本、应用名、图标。
 * - 已安装应用：直接走 PackageManager（最准）。
 * - 本地 APK 文件：解压 AndroidManifest.xml，用简易 AXML 字符串提取包名；
 *   图标优先解析 binary XML 的 applicationIcon，失败时回退 res/mipmap 目录扫描。
 *
 * 说明：完整二进制 AXML 解析较复杂，此处提供「字符串提取 + 图标扫描」的可用实现，
 * 足以满足前端「从 APK 读取应用信息回填卡片」的需求。加固 APK 需加固厂商 SDK 配合。
 */
public class ApkManifestParser {

    /** 结果容器 */
    public static class AppInfo {
        public String pkg;
        public String versionName;
        public int versionCode;
        public String appName;
        public String iconPath; // APK 内图标相对路径，可用于提取
    }

    /** 解析已安装应用（精确） */
    public static AppInfo fromInstalled(Context ctx, String pkg) {
        AppInfo info = new AppInfo();
        try {
            PackageManager pm = ctx.getPackageManager();
            PackageInfo pi = pm.getPackageInfo(pkg, 0);
            info.pkg = pi.packageName;
            info.versionName = pi.versionName;
            info.versionCode = (int) pi.getLongVersionCode();
            info.appName = pm.getApplicationLabel(pi.applicationInfo).toString();
            info.iconPath = null;
        } catch (Exception e) { /* ignore */ }
        return info;
    }

    /** 解析本地 APK 文件（字符串提取 + 图标扫描） */
    public static AppInfo fromFile(File apk) {
        AppInfo info = new AppInfo();
        try (ZipFile zf = new ZipFile(apk)) {
            // 1. 提取包名：从 AndroidManifest.xml 的字符串池里找形如 com.xxx.yyy 的包名
            ZipEntry mf = zf.getEntry("AndroidManifest.xml");
            if (mf != null) {
                byte[] data = readEntry(zf, mf);
                info.pkg = extractPackage(data);
                // 尝试提取 versionName / versionCode 属性（字符串匹配）
                String s = new String(data, "ISO-8859-1");
                java.util.regex.Matcher m = java.util.regex.Pattern.compile("versionName=\"([^\"]*)\"").matcher(s);
                if (m.find()) info.versionName = m.group(1);
            }
            // 2. 图标：扫描 res/mipmap* 下 ic_launcher(.round)?.png
            info.iconPath = scanLauncherIcon(zf);
        } catch (Exception e) { /* ignore */ }
        return info;
    }

    /** 简易从二进制 AXML 字节中提取包名（找最长合法 java 包名字符串） */
    private static String extractPackage(byte[] data) {
        String s = new String(data, 0, Math.min(data.length, 64 * 1024), java.nio.charset.StandardCharsets.ISO_8859_1);
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("[a-z][a-z0-9_]*(\\.[a-z][a-z0-9_]*){2,}")
                .matcher(s);
        String best = "";
        while (m.find()) { if (m.group().length() > best.length()) best = m.group(); }
        return best;
    }

    private static String scanLauncherIcon(ZipFile zf) {
        java.util.List<String> cands = new java.util.ArrayList<>();
        java.util.Enumeration<? extends ZipEntry> en = zf.entries();
        while (en.hasMoreElements()) {
            String n = en.nextElement().getName();
            if (n.matches("res/mipmap[a-z-]*/ic_launcher(-round)?\\.png")) cands.add(n);
        }
        if (cands.isEmpty()) return null;
        // 优先 xxxhdpi > xxhdpi > ...
        cands.sort((a, b) -> densityRank(b) - densityRank(a));
        return cands.get(0);
    }
    private static int densityRank(String path) {
        if (path.contains("xxxhdpi")) return 4;
        if (path.contains("xxhdpi")) return 3;
        if (path.contains("xhdpi")) return 2;
        if (path.contains("hdpi")) return 1;
        return 0;
    }

    private static byte[] readEntry(ZipFile zf, ZipEntry e) throws java.io.IOException {
        try (java.io.InputStream is = zf.getInputStream(e);
             java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream()) {
            byte[] buf = new byte[4096];
            int n;
            while ((n = is.read(buf)) > 0) bos.write(buf, 0, n);
            return bos.toByteArray();
        }
    }
}
