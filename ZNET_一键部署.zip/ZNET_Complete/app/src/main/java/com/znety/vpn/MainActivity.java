package com.znety.vpn;

import android.app.Activity;
import android.content.Intent;
import android.net.VpnService;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONObject;

/**
 * 主入口：WebView 承载前端 index.html，通过 JavascriptInterface 与前端双向通信。
 * 前端点「启动」→ request_vpn_permission → 系统弹 VPN 授权框 → 同意后启动 QnetyVpnService。
 */
public class MainActivity extends Activity {

    private static final int REQ_VPN = 1001;
    private WebView web;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private JSONObject pendingConfig; // 授权通过后用于启动 VPN 的配置

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        web = new WebView(this);
        web.setLayoutParams(new android.view.ViewGroup.LayoutParams(-1, -1));
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);

        // JS 调原生：window.qnetAndroidObj.callAndroidApi(json)
        web.addJavascriptInterface(new QnetAndroidObj(this, this::callJs), "qnetAndroidObj");
        web.setWebViewClient(new WebViewClient());
        web.loadUrl("file:///android_asset/index.html");
    }

    /** 原生回调前端：evaluateJavascript */
    void callJs(String js) {
        ui.post(() -> web.evaluateJavascript(js, null));
    }

    /** 请求 VPN 授权（由 QnetAndroidObj 调用） */
    void requestVpnPermission(JSONObject config) {
        this.pendingConfig = config;
        Intent intent = VpnService.prepare(this);
        if (intent != null) {
            startActivityForResult(intent, REQ_VPN);
        } else {
            // 已经授权过，直接启动
            startVpn(config);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_VPN && resultCode == RESULT_OK) {
            startVpn(pendingConfig);
        } else if (requestCode == REQ_VPN) {
            callJs("toast('VPN 授权被取消')");
        }
    }

    private void startVpn(JSONObject config) {
        Intent it = new Intent(this, QnetyVpnService.class);
        if (config != null) it.putExtra("config", config.toString());
        startForegroundService(it);
        callJs("if(typeof running!=='undefined'){running=true;document.getElementById('startBtn').textContent='停止';document.getElementById('startBtn').classList.add('running');document.getElementById('statusTxt').textContent='已连接';}");
    }

    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }
}
