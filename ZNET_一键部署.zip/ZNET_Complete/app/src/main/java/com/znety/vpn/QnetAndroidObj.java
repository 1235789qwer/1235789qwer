package com.znety.vpn;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.webkit.JavascriptInterface;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * JS 桥接对象：前端 window.qnetAndroidObj.callAndroidApi(json) 的统一入口。
 * json = {action, data}，根据 action 分发到对应原生能力。
 */
public class QnetAndroidObj {

    private final Context ctx;
    private final MainActivity activity;
    private final Handler ui = new Handler(Looper.getMainLooper());

    public QnetAndroidObj(Context ctx, MainActivity activity) {
        this.ctx = ctx;
        this.activity = activity;
    }

    @JavascriptInterface
    public void callAndroidApi(String json) {
        try {
            JSONObject msg = new JSONObject(json == null ? "{}" : json);
            String action = msg.optString("action");
            JSONObject data = msg.optJSONObject("data");
            if (data == null) data = new JSONObject();

            switch (action) {
                case "request_vpn_permission": handleVpn(data); break;
                case "start_qnet":             handleStart(data); break;
                case "stop_qnet":              handleStop(data); break;
                case "update_qnet":            handleUpdate(data); break;
                case "set_package_name":       handlePackage(data); break;
                case "get_installed_apps":     handleApps(data); break;
                case "parse_app_zip":          handleParse(data); break;
                default: reply("unknown", action);
            }
        } catch (Exception e) {
            reply("error", e.getMessage());
        }
    }

    // 1. 请求 VPN 授权（系统弹框）
    private void handleVpn(JSONObject d) {
        ui.post(() -> activity.requestVpnPermission(d));
    }

    // 2. 启动 VPN（先要授权）
    private void handleStart(JSONObject d) {
        ui.post(() -> activity.requestVpnPermission(d));
    }

    // 3. 停止 VPN
    private void handleStop(JSONObject d) {
        ctx.stopService(new android.content.Intent(ctx, QnetyVpnService.class));
        callJs("if(typeof running!=='undefined'){running=false;document.getElementById('startBtn').textContent='启动';document.getElementById('startBtn').classList.remove('running');document.getElementById('statusTxt').textContent='未连接';}");
    }

    // 4. 运行中实时更新参数（热更新，无需断流）
    private void handleUpdate(JSONObject d) {
        VpnController.getInstance().updateConfig(d);
        callJs("toast('参数已实时更新')");
    }

    // 5. 设置只对指定包名生效
    private void handlePackage(JSONObject d) {
        String pkg = d.optString("package");
        VpnController.getInstance().setTargetPackage(pkg);
    }

    // 6. 读取设备全部已安装应用（返回给前端渲染列表）
    private void handleApps(JSONObject d) {
        ui.post(() -> {
            try {
                PackageManager pm = ctx.getPackageManager();
                List<ApplicationInfo> apps = pm.getInstalledApplications(PackageManager.GET_META_DATA);
                JSONArray arr = new JSONArray();
                for (ApplicationInfo ai : apps) {
                    if ((ai.flags & ApplicationInfo.FLAG_SYSTEM) != 0 && !isUserApp(ai)) continue;
                    JSONObject o = new JSONObject();
                    o.put("name", pm.getApplicationLabel(ai).toString());
                    o.put("pkg", ai.packageName);
                    o.put("icon", ""); // 图标 base64 按需扩展
                    arr.put(o);
                    if (arr.length() >= 200) break; // 防止过多
                }
                callJs("loadInstalledApps(" + arr.toString() + ")");
            } catch (Exception e) {
                callJs("loadInstalledApps([])");
            }
        });
    }

    // 7. 从 ZIP/APK 读取应用信息（前端已用 JSZip 解析，此处做原生兜底）
    private void handleParse(JSONObject d) {
        // JSZip 已在 WebView 侧解析 manifest + 图标；原生侧如需二进制 AXML 解析在此扩展
        callJs("toast('APK 解析完成（原生兜底就绪）')");
    }

    private boolean isUserApp(ApplicationInfo ai) {
        return (ai.flags & ApplicationInfo.FLAG_INSTALLED) != 0;
    }

    private void reply(String type, String msg) {
        callJs("console.log('" + type + ":" + msg + "')");
    }

    private void callJs(String js) {
        if (activity != null) activity.callJs(js);
    }
}
