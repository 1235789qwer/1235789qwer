# ZNET · nextz弱网（完整源码 + 云端自动出包）

> **目标**：1:1 还原「泽北 ZNET / nextz弱网」正版布局，并实现**真实 VPN 弱网控网**（改延迟、丢包、带宽即时生效）。
> **适用**：没电脑也能出 APK —— 全程手机浏览器操作，靠 **GitHub Actions 云端编译**。

---

## 一、工程结构

```
ZNET_Complete/
├── .github/workflows/build.yml   ← GitHub Actions：push 自动出 APK
├── build.gradle                  ← 项目级 Gradle 配置
├── settings.gradle
├── gradlew / gradle/wrapper/     ← Gradle Wrapper（云端自动下载 Gradle）
├── app/
│   ├── build.gradle              ← App 模块（SDK34 / Java17 / 无 Kotlin）
│   └── src/main/
│       ├── AndroidManifest.xml   ← VpnService + 权限 + 前台服务
│       ├── assets/index.html     ← ★ 前端：1:1 正版布局（单文件，零外链）
│       └── java/com/znety/vpn/
│           ├── MainActivity.java     ← WebView + JS 桥接 + VPN 授权回调
│           ├── QnetAndroidObj.java   ← 桥接核心（7 个 action 全对齐）
│           ├── QnetyVpnService.java  ← ★ 真实 VPN 隧道 + 弱网整形
│           ├── VpnController.java    ← ★ 参数热更新（运行时不重连）
│           └── ApkManifestParser.java← 从 APK 读包名/图标（原生兜底）
```

**前端 → 原生桥接对照**（一一对齐，前端 action = 原生 handler）：

| 前端 action | 原生 handler | 作用 |
|---|---|---|
| `request_vpn_permission` | `MainActivity.requestVpnPermission` | 弹系统 VPN 授权框 |
| `start_qnet` | `handleStart` → 启动 `QnetyVpnService` | 建立 Tun 隧道 |
| `stop_qnet` | `handleStop` | 停 VPN |
| `update_qnet` | `VpnController.updateConfig` | **运行中实时改参数** |
| `set_package_name` | `setTargetPackage` | 只对选中应用生效 |
| `get_installed_apps` | `handleApps` | 读设备全部应用 |
| `parse_app_zip` | `handleParse` | APK/ZIP 解析兜底 |

---

## 二、没电脑？用 GitHub Actions 云端出包（推荐）

全程手机浏览器操作，约 5-10 分钟自动出 APK，下载直接装手机。

### 步骤
1. **注册 GitHub**：手机浏览器打开 github.com，免费注册账号 → 验证邮箱。
2. **新建仓库**：点右上角 `+` → New repository → 名字填 `znet-app` → 选 **Public** → Create。
3. **上传代码**：进仓库 → Add file → Upload files → 把本工程**所有文件**按原目录结构拖进去（保留 `app/`、`gradle/`、`build.gradle` 等结构）→ Commit。
4. **开启 Actions**：仓库顶部点 **Actions** 标签 → 点绿色 "I understand my workflows, go ahead" → 它会自动检测 `.github/workflows/build.yml`。
5. **触发编译**：push 任意改动（或到 Actions 页手动 Run workflow）→ 等约 5-10 分钟 → 状态变绿 ✅。
6. **下载 APK**：进仓库 **Actions → 最新那条 → 右侧 Artifacts 区 → `ZNET-APK`** → 下载 `app-debug.apk`。
7. **安装**：手机设置 → 安全 → 允许「未知来源安装」→ 装 APK → 打开 → 选应用 → 启动 → **系统弹 VPN 授权 → 同意 → 状态栏钥匙图标亮 = 真正连上**。

> 首次编译若报错，到 Actions 日志里看红字，通常是 SDK 许可问题 —— 在 `build.yml` 里加一步 `yes | sdkmanager --licenses` 即可（已内置注释引导）。

---

## 三、有电脑？Android Studio 一键出包

1. 装 **Android Studio + JDK17**，SDK Manager 勾选 **API 34** 平台。
2. Android Studio → Open → 选本工程根目录 `ZNET_Complete/`。
3. 等 **Gradle Sync** 自动下载依赖（Gradle 8.7 + AGP 8.5 + appcompat）。
4. 手机 USB 调试连电脑 → 点 ▶ Run → 自动装到手机；或右侧 Gradle → app → build → **assembleDebug**。
5. APK 产物在 `app/build/outputs/apk/debug/app-debug.apk`。

---

## 四、功能说明

- **正版布局**：蓝绿顶栏 ZNET、搜索栏、全部应用/全局生效、启动/停止、场景开·泽北·自定义、上下行参数（带宽/延时/抖动速率/通包时长/丢包率/突发丢包）、协议选择弹层（全部/TCP/UDP/TCP+UDP）、新建模板、设置（账号/云端同步/上传云端/测试报告/悬浮窗控制·信息/防封禁）、悬浮控制面板（刷新/暂停/展开）。
- **从 APK/ZIP 读取应用**：选文件 → JSZip 解 manifest 提包名 + 图标 → 回填卡片（前端已实现；加固 APK 二进制 manifest 由 `ApkManifestParser` 原生兜底）。
- **真实 VPN 控网**：`QnetyVpnService.establish()` 建 Tun 隧道 → 令牌桶限带宽 → 概率丢包 → 延时入队 → 参数用原子变量存储，**运行中改参数即时生效、无需断流**。

---

## ⚠️ 诚实说明

`QnetyVpnService.tunLoop()` 给出了**完整可运行骨架**（隧道建立、参数热更新、令牌桶、丢包均已实现并可用）。
要做"逐 TCP 流精准整形"（per-flow 队列、TCP/UDP 协议区分、抖动随机化），需在 `tunLoop` 里补充 **IP/TCP/UDP 包头解析 + 每流延迟队列** —— 这是弱网引擎的核心，正版 ZNET 的"不拉回"优化即在此处。骨架已留好接口（`VpnController` 的 jitter/burst 字段 + 协议选择 `proto`），补全后即可达到正版效果。

参数 `-1` = 默认不限制；`0` 或正数 = 启用限制，与正版 UI 完全一致。

---

**任何问题**：先看 GitHub Actions 编译日志，或把报错发回来，我直接改 `build.yml` / 源码。
